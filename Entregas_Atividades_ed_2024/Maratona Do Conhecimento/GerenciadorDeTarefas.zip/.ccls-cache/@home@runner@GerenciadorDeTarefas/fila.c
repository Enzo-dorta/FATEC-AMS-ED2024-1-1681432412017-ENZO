#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void listarConcluidas(FILA *fila, int pessoa){
  TAREFA *temp = fila->inicio;

        if(fila == NULL){
        printf("nenhuma tarefa foi concluida");
        }

  printf("");

  while(temp->next != NULL)
    {
        if(pessoa == temp->idP || pessoa == 0){
        printf("Titulo da Tarefa: %s\n Descrição: %s\n Prazo: %d\n Responsável: ", temp->titulo, temp->descricao,temp->prazo);
          switch(temp->idP)
            {
              case 1:
                printf("Bruna\n \n");
              break;
              case 2:
                printf("Carla\n \n");
              break;
              case 3:
                printf("Joao\n \n");
              break;

            }
        }
    }

      temp = temp->next;
    }